//
//  ClaySDK.h
//  ClaySDK
//
//  Created by Arthur Schenk on 20/06/2017.
//  Copyright © 2017 Clay Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>

FOUNDATION_EXPORT double ClaySDKVersionNumber;
FOUNDATION_EXPORT const unsigned char ClaySDKVersionString[];
